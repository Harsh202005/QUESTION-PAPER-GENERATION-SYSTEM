/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package staff;

import admin.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author welcome
 */
public class Info_DataFeatcher
{
      public ArrayList getData(String teachername)
    {
        ArrayList data=new ArrayList();
        try
        {
            
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/automaticquestionpapergenerator","root","root");
            Statement st=conn.createStatement();
            
            String query="select * from questions where teacher_name='"+teachername+"' ";
            
            ResultSet rs=st.executeQuery(query);
            while(rs.next())
            {
                ArrayList a=new ArrayList();
                a.add(rs.getString(2));
                a.add(rs.getString(3));
                a.add(rs.getString(4));
//                a.add(rs.getString(5));
//                a.add(rs.getString(6));
//                a.add(rs.getString(7));
//                a.add(rs.getString(8));
                data.add(a);
            }
                
            System.out.println("data is:"+data);
            conn.close();
            st.close();
        }
        catch(Exception ex)
        {
            System.out.println("Exception is: "+ex);
        }
        return data;
    }
}
