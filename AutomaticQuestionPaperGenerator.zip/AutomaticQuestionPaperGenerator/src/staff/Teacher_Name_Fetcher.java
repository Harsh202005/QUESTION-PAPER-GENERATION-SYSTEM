/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package staff;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author welcome
 */
public class Teacher_Name_Fetcher
{
     public String getTeacher_name(String username)
    {
       String teacher_name="";
        try
        {
             Class.forName("com.mysql.jdbc.Driver").newInstance();
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/automaticquestionpapergenerator","root","root");
           Statement st=con.createStatement();
           
           String query="select * from registration_info where user_name='"+username+"'";
           
           ResultSet rs=st.executeQuery(query);
           if(rs.next())
           {
               teacher_name=rs.getString(1);
           }
        }
        catch(Exception ex)
        {
            System.out.println("Exception is: "+ex);
        }
        return teacher_name;
    }
}
