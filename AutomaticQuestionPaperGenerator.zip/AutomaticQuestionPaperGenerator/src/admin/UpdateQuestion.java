/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package admin;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

/**
 *
 * @author welcome
 */
public class UpdateQuestion 
{
     public boolean doEdit(String srno,String dept,String sem,String sub,String unit,String que,String level,String marks,String teachername )
    {
        boolean flag=true;
        try
        {
             Class.forName("com.mysql.jdbc.Driver").newInstance();
            Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/automaticquestionpapergenerator","root","root");
            Statement st=conn.createStatement();
            
            String query="update questions set department='"+dept+"',semester='"+sem+"',subject='"+sub+"',unit='"+unit+"',question='"+que+"',level_of_que='"+level+"',marks='"+marks+"',teacher_name='"+teachername+"' where sr_no='"+srno+"'";
            
            int x=st.executeUpdate(query);
            if(x>0)
                flag=true;
            else
                flag=false;
        }
        catch(Exception ex)
        {
            System.out.println("Exception is: "+ex);
        }
        return flag;
    }
}
