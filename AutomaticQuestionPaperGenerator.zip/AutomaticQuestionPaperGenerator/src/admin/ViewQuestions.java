/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package admin;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author welcome
 */
public class ViewQuestions 
{
    public void getViewQuestions()
    {
        try
        {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/automaticquestionpapergenerator","root","root");
            Statement st1=conn.createStatement();
            Statement st2=conn.createStatement();
            String query="select * from questions";
            ResultSet rs1=st1.executeQuery(query);
            ResultSet rs2=st2.executeQuery(query);
            
            int row=0;
            while(rs1.next())
            {
                row++;
            }
            String data[][]=new String[row][9];
            int i=0;
            while(rs2.next())
            {
                String srno=rs2.getString(1);
                data[i][0]=srno;
                String dept=rs2.getString(2);
                data[i][1]=dept;
                String sem=rs2.getString(3);
                data[i][2]=sem;
                String sub=rs2.getString(4);
                data[i][3]=sub;
                String unit=rs2.getString(5);
                data[i][4]=unit;
                String que=rs2.getString(6);
                data[i][5]=que;
                String level=rs2.getString(7);
                data[i][6]=level;
                String marks=rs2.getString(8);
                data[i][7]=marks;
                String teachername=rs2.getString(9);
                data[i][8]=teachername;
                
                
                   i++;
            }
            ViewQuestionsFrame.data=data;
        }
        catch(Exception ex)
        {
            System.out.println("Exception is: "+ex);
        }
    }
}
