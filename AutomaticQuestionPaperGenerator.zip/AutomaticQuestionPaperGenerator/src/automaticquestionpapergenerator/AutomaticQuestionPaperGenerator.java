/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package automaticquestionpapergenerator;

import java.awt.Dimension;
import java.awt.Toolkit;
import staff.RandomNumGenerator;

/**
 *
 * @author welcome
 */
public class AutomaticQuestionPaperGenerator {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        LoginFrame lf=new LoginFrame();
        Dimension d=Toolkit.getDefaultToolkit().getScreenSize();
        lf.setVisible(true);
        lf.setSize(d);
//        RandomNumGenerator rg=new RandomNumGenerator();
//        for (int i = 0; i < 100; i++) 
//        {
//           int x= rg.getRandomNumber(1, 10);
//            System.out.println("X is : "+x);            
//        }
        
    }
    
}
